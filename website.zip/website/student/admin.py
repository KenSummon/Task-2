from django.contrib import admin
from .models import Classz, Student

admin.site.register(Classz)
admin.site.register(Student)